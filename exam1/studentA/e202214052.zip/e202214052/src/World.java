public class World {

  public static void run() {
    System.out.println("202214052");
  }

  public static void run2() {
    System.out.println("hello world");
  }

}
