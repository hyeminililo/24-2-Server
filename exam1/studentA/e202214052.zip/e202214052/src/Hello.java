public class Hello {

  public static void run() {
    System.out.println("hello world");
  }

}
